"use client"

import { useState, useEffect, useCallback } from "react"

export interface CartItem {
  id: number
  name: string
  material: string
  price: number
  image: string
  size: string
  quantity: number
}

const CART_KEY = "bay-jewellers-cart"

function loadCart(): CartItem[] {
  if (typeof window === "undefined") return []
  try {
    const stored = localStorage.getItem(CART_KEY)
    return stored ? JSON.parse(stored) : []
  } catch {
    return []
  }
}

function saveCart(items: CartItem[]) {
  if (typeof window === "undefined") return
  localStorage.setItem(CART_KEY, JSON.stringify(items))
}

// Simple global state via module-level variable + listeners
let globalCart: CartItem[] = loadCart()
const listeners = new Set<() => void>()

function notify() {
  listeners.forEach((fn) => fn())
}

export function addToCart(item: Omit<CartItem, "quantity">) {
  const existing = globalCart.find((i) => i.id === item.id && i.size === item.size)
  if (existing) {
    globalCart = globalCart.map((i) =>
      i.id === item.id && i.size === item.size ? { ...i, quantity: i.quantity + 1 } : i
    )
  } else {
    globalCart = [...globalCart, { ...item, quantity: 1 }]
  }
  saveCart(globalCart)
  notify()
}

export function removeFromCart(id: number, size: string) {
  globalCart = globalCart.filter((i) => !(i.id === id && i.size === size))
  saveCart(globalCart)
  notify()
}

export function updateQuantity(id: number, size: string, quantity: number) {
  if (quantity <= 0) {
    removeFromCart(id, size)
    return
  }
  globalCart = globalCart.map((i) =>
    i.id === id && i.size === size ? { ...i, quantity } : i
  )
  saveCart(globalCart)
  notify()
}

export function clearCart() {
  globalCart = []
  saveCart(globalCart)
  notify()
}

export function useCart() {
  const [items, setItems] = useState<CartItem[]>(globalCart)

  useEffect(() => {
    const refresh = () => setItems([...globalCart])
    listeners.add(refresh)
    return () => { listeners.delete(refresh) }
  }, [])

  const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0)
  const totalItems = items.reduce((sum, i) => sum + i.quantity, 0)

  return { items, total, totalItems, addToCart, removeFromCart, updateQuantity, clearCart }
}
