"use client"

import { useState, useEffect } from "react"

const WISHLIST_KEY = "bay-jewellers-wishlist"

function loadWishlist(): Set<number> {
  if (typeof window === "undefined") return new Set()
  try {
    const stored = localStorage.getItem(WISHLIST_KEY)
    return stored ? new Set(JSON.parse(stored)) : new Set()
  } catch {
    return new Set()
  }
}

function saveWishlist(set: Set<number>) {
  if (typeof window === "undefined") return
  localStorage.setItem(WISHLIST_KEY, JSON.stringify([...set]))
}

let globalWishlist: Set<number> = loadWishlist()
const listeners = new Set<() => void>()

function notify() {
  listeners.forEach((fn) => fn())
}

export function toggleWishlist(id: number) {
  if (globalWishlist.has(id)) {
    globalWishlist.delete(id)
  } else {
    globalWishlist.add(id)
  }
  globalWishlist = new Set(globalWishlist)
  saveWishlist(globalWishlist)
  notify()
}

export function isWishlisted(id: number) {
  return globalWishlist.has(id)
}

export function useWishlist() {
  const [wishlist, setWishlist] = useState<Set<number>>(globalWishlist)

  useEffect(() => {
    const refresh = () => setWishlist(new Set(globalWishlist))
    listeners.add(refresh)
    return () => { listeners.delete(refresh) }
  }, [])

  return {
    wishlist,
    count: wishlist.size,
    has: (id: number) => wishlist.has(id),
    toggle: toggleWishlist,
  }
}
